<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
  
<form action="?pg=salvardb"  method="post">
<table> 
    <tr> 
        <td>Nome do produto: </td>
        <td><input name="produto" type="text"/></td>
    </tr>
    <tr> 
        <td>Preço: </td>
        <td><input name="preco" type="text"/></td>
    </tr>
    <tr>
        <td>Quantidade: </td>
        <td><input name="quantidade" type="text"></textarea></td>
    </tr>
    <tr>
        <td></td>
        <td><button name="Enviar">Cadastrar</button></td>
    </tr>
</table>
</form>
</body>
</html>